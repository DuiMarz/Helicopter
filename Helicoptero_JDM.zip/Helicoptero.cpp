/* Helicoptero.cpp
*/

// Bibliotecas de C++
#include <iostream>
#include <string>
#include <sstream>

// Bibliotecas graficas
#include <Utilidades.h>

using namespace std;

//Contantes
const float EXT = 10000.0;
const float RES = 100.0;

//Globales

static enum { DIA, NOCHE } modo;

static float tama�oQuad = EXT / RES;
static float camara[3] = { 0,-30,100 };
static float anguloCamara = 0.0, modulo, maxZ;
static int xanterior, yanterior;
static float giroX = 0, giroY = 0;
float VxUp, VxDown, VyUp, VyDown;

static GLfloat cuadri[8];
static GLuint malla, medidor;
static GLfloat nieblaDia[] = { 0.0,1.0,1.0,1.0 };
static GLfloat nieblaNoche[] = { 0.0,0.0,0.1,1.0 };
static GLfloat S[] = { 0,1,0,0.5 };
static GLfloat T[] = { 0,0,1,-0.5 };

int fps;

GLuint bosque, montanya1, montanya2, cabina, brujula,velocimetro, altimetro, manecilla, manecilla2;

static bool cambiocolor = false;
static bool focoEncendido = false;
static bool pilotoAutoOn = false;


void reinicio() {
	cuadri[0] = EXT / 2.0 + tama�oQuad/2.0;					//V0 x
	cuadri[1] = EXT / 2.0;					//V0 y

	cuadri[2] = cuadri[0] - tama�oQuad;     //V1 x
	cuadri[3] = EXT / 2.0;				    //V1 y

	cuadri[4] = cuadri[0];					//V2 x
	cuadri[5] = EXT / 2.0 - tama�oQuad;		//V2 y

	cuadri[6] = cuadri[0] - tama�oQuad;					//V3 x
	cuadri[7] = EXT / 2.0 - tama�oQuad;						//V3 y

}

void moverFilaAbajo(int k) {
	for (int aux = 0; aux <= 6; aux += 2) {
		cuadri[aux] -= tama�oQuad * k;
	}

}

float elevacion(float x, float y) {
	return sin(y/5) * cos(x/10) * 150;
}

void init()
{

	//Texturas
	glGenTextures(1, &bosque);
	glBindTexture(GL_TEXTURE_2D, bosque);
	loadImageFile((char*)"bosque.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	
	glGenTextures(1, &montanya1);
	glBindTexture(GL_TEXTURE_2D, montanya1);
	loadImageFile((char*)"monta�a1.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &montanya2);
	glBindTexture(GL_TEXTURE_2D, montanya2);
	loadImageFile((char*)"monta�a2.jpg");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &cabina);
	glBindTexture(GL_TEXTURE_2D, cabina);
	loadImageFile((char*)"cabina.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &brujula);
	glBindTexture(GL_TEXTURE_2D, brujula);
	loadImageFile((char*)"brujula.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &velocimetro);
	glBindTexture(GL_TEXTURE_2D, velocimetro);
	loadImageFile((char*)"velocimetro.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &manecilla);
	glBindTexture(GL_TEXTURE_2D, manecilla);
	loadImageFile((char*)"manecilla.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &manecilla2);
	glBindTexture(GL_TEXTURE_2D, manecilla2);
	loadImageFile((char*)"manecilla2.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenTextures(1, &altimetro);
	glBindTexture(GL_TEXTURE_2D, altimetro);
	loadImageFile((char*)"altimetro.png");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	modo = DIA;
	reinicio();

	float altura;
	modulo = sqrt((pow(cos(rad(anguloCamara)), 2) + pow(sin(rad(anguloCamara)), 2)));


	

	//Lista que crea la malla del terreno
	malla = glGenLists(1);
	glNewList(malla, GL_COMPILE);
	glPushMatrix();

	for (int k = 1; k <= RES; k++) {				//N� DE FILAS
		glBegin(GL_QUAD_STRIP);
		for (int j = 0; j < RES; j++) {				//FILA DE "RES" CUADRADOS
			maxZ = -1000;		
			for (auto i = 0; i < 7; i += 2) {      
				altura = elevacion(cuadri[i], cuadri[i + 1]);	//A cada v�rtice le damos una altura dependiendo de su posici�n
				if (altura > maxZ) { maxZ = altura; }
					
			}

			if (maxZ <= 75 ) {
				glBindTexture(GL_TEXTURE_2D, bosque);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);

				glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			}
			else if (maxZ >= 100) {
				glBindTexture(GL_TEXTURE_2D, montanya2);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);

				glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			}
			else {
				glBindTexture(GL_TEXTURE_2D, montanya1);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);

				glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			}
			

			for (auto i = 0; i < 7; i += 2) {       //UN CUADRADO

				altura = elevacion(cuadri[i], cuadri[i + 1]);	//A cada v�rtice le damos una altura dependiendo de su posici�n
				switch (i) {
				case 0: glTexCoord2f(0, 0); break;
				case 2: glTexCoord2f(1, 0); break;
				case 4: glTexCoord2f(1, 1); break;
				case 6: glTexCoord2f(0,1); break;
				}
				glVertex3f(cuadri[i], cuadri[i + 1], altura);
				cuadri[i + 1] = cuadri[i + 1] - tama�oQuad;		//Movemos a la derecha el punto
			}
		

			cambiocolor = !cambiocolor;
		}
		reinicio();
		moverFilaAbajo(k);
		cambiocolor = !cambiocolor;
		glEnd();
	}
	glPopMatrix();
	glEndList();




	//LUCES
	const GLfloat L0D[]{0.15,0.15,0.15,1 };		//LUNA
	glLightfv(GL_LIGHT0, GL_DIFFUSE, L0D);
	
	GLfloat Al1[] = { 0.2,0.2,0.2,1.0 }; 
	GLfloat Dl1[] = { 0.5,0.5,0.0,1.0 }; 
	GLfloat Sl1[] = { 0.5,0.5,0.0,1.0 }; 
	glLightfv(GL_LIGHT1, GL_AMBIENT, Al1); // Caracteristicas de LIGHT1 (FOCO FIJO)
	glLightfv(GL_LIGHT1, GL_DIFFUSE, Dl1);
	glLightfv(GL_LIGHT1, GL_SPECULAR, Sl1);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 20.0);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 2.0);


	GLfloat Al2[] = { 1.0,1.0,1.0,1.0 };
	GLfloat Dl2[] = { 1.0,1.0,0.0,1.0 };
	GLfloat Sl2[] = { 1.0,1.0,0.0,1.0 };
	glLightfv(GL_LIGHT2, GL_AMBIENT, Al2); // Caracteristicas de LIGHT2 (FOCO M�VIL)
	glLightfv(GL_LIGHT2, GL_DIFFUSE, Dl2);
	glLightfv(GL_LIGHT2, GL_SPECULAR, Sl2);
	glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 10.0);
	glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 2.0);
	
	

	

	//Niebla
	glClearColor(0.0f, 1.0f, 1.0f, 1.0f); //0,1,1 para azul cielo diurno y 0,0,0.1 para azul noche
	glEnable(GL_FOG);
	glFogfv(GL_FOG_COLOR, nieblaDia);
	glFogf(GL_FOG_DENSITY, 0.002);

	//ENABLES
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);
}

//Calculo vertices m�s cercanos a m�
float alturaSuelo() {

	VxUp = ceil(camara[0] / tama�oQuad) * tama�oQuad;
	VxDown = floor(camara[0] / tama�oQuad) * tama�oQuad;

	VyUp = ceil(camara[1] / tama�oQuad) * tama�oQuad;
	VyDown = floor(camara[1] / tama�oQuad) * tama�oQuad;

	
	

	float V1[3] = { VxUp,VyUp,0 };
	float V2[3] = { VxUp,VyDown,0 };
	float V3[3] = { VxDown,VyUp,0 };
	float V4[3] = { VxDown,VyDown,0 };

	V1[2] = elevacion(V1[0], V1[1]);
	
	V2[2] = elevacion(V2[0], V2[1]);
	
	V3[2] = elevacion(V3[0], V3[1]);
	
	V4[2] = elevacion(V4[0], V4[1]);
	


	
	return ((V1[2] + V2[2] + V3[2] + V4[2]) / 4.0);
	
}

void FPS() {
	//Muestra FPS actuales en el titulo de la ventana
	int ahora, tiempo_transcurrido;
	static int antes = glutGet(GLUT_ELAPSED_TIME);
	static int fotogramas = 0;

	//cada vez que llamo a FPS se incrementan los fotogramas
	fotogramas++;

	//Calculo el tiempo transcurrido entre dos fotogramas
	ahora = glutGet(GLUT_ELAPSED_TIME);
	tiempo_transcurrido = ahora - antes;

	//Si ha transcurrido m�s de un segundo, muestro los FPS y reinicio el reloj (glueGet devuelve en milisegundos)
	if (tiempo_transcurrido > 1000) {

		fps = fotogramas;
		//Reiniciar reloj y los fotogramas
		fotogramas = 0;
		antes = ahora;

	}
}

void display()
{
	// Callback de dibujo 

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//FOCO MOVIL
	GLfloat L2P[]{ 0, 0, 0,1 };
	glLightfv(GL_LIGHT2, GL_POSITION, L2P); // Luz focal sobre la camara
	GLfloat dir_central_l2[] = { 0,0, -1 }; // Direccion del foco la de la vista
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, dir_central_l2);

	gluLookAt(camara[0], camara[1], camara[2], camara[0]+cos(rad(giroY))*cos(rad(giroX)), camara[1] + sin(rad(giroY))* cos(rad(giroX)), camara[2] + sin(rad(giroX)), 0, 0, 1);
	

	//LUNA
	GLfloat L0P[]{ 0,0,10,0 };
	glLightfv(GL_LIGHT0, GL_POSITION, L0P);

	//FOCO FIJO
	GLfloat L1P[]{ camara[0], camara[1], camara[2],1 };
	glLightfv(GL_LIGHT1, GL_POSITION, L1P); // Luz focal sobre la camara
	GLfloat dir_central[] = { cos(rad(anguloCamara)),sin(rad(anguloCamara)), -1.0 }; // Direccion del foco la de la vista
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir_central);
	
	glPushMatrix();
	glCallList(malla);
	glPopMatrix();

	
	//------------------------CABINA--------------------------------
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, cabina);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_S, GL_OBJECT_PLANE, S);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGenfv(GL_T, GL_OBJECT_PLANE, T);

	glTranslatef(camara[0], camara[1], camara[2]);
	glScalef(6,6,6);
	glRotatef(anguloCamara,0,0,1);
	glRotatef(180, 1, 0, 0);
	glOrtho(-1, 1, -1, 1, -1, 1);
	glutSolidSphere(0.5, 20, 20);
	glPopMatrix();
	glPopAttrib();

	//----------------------------BRUJULA---------------------
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, brujula);

	
	glTranslatef(camara[0], camara[1], camara[2]);
	
	glRotatef(anguloCamara, 0, 0, 1);
	glRotatef(anguloCamara, 1, 0, 0);
	glRotatef(90, 1, 0, 0);
	glTranslatef(2, 0, 0);
	glColor3fv(NEGRO);

	glBegin(GL_POLYGON);
	glTexCoord2f(0, 0);
	glVertex3f(0, -0.2, -0.2);
	glTexCoord2f(1, 0);
	glVertex3f(0, -0.2, 0.2);
	glTexCoord2f(1, 1);
	glVertex3f(0, 0.2, 0.2);
	glTexCoord2f(0, 1);
	glVertex3f(0, 0.2, -0.2);
	glEnd();
	glPopMatrix();
	glPopAttrib();

	

	//--------------------------------VELOCIMETRO----------
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, velocimetro);

	glTranslatef(camara[0], camara[1], camara[2]);
	glRotatef(anguloCamara, 0, 0, 1);
	glTranslatef(2, 0.4, -0.8);
	glRotatef(90, 1, 0, 0);
	glBegin(GL_POLYGON);
	glTexCoord2f(0, 0);
	glVertex3f(0, -0.2, -0.2);
	glTexCoord2f(1, 0);
	glVertex3f(0, -0.2, 0.2);
	glTexCoord2f(1, 1);
	glVertex3f(0, 0.2, 0.2);
	glTexCoord2f(0, 1);
	glVertex3f(0, 0.2, -0.2);
	glEnd();
	glPopMatrix();
	glPopAttrib();

	

	//-----------------------MANECILLA 1-----------------------------


	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, manecilla);
	
	glTranslatef(camara[0], camara[1], camara[2]);
	glRotatef(anguloCamara, 0, 0, 1);
	glTranslatef(1.9, 0.39, -0.77);
	glRotatef(16, 1, 0, 0);
	glRotatef(modulo, 1, 0, 0);
	glScalef(0, 0.8, 0.8);
	

	glBegin(GL_POLYGON);
	glTexCoord2f(0, 0);
	glVertex3f(0, -0.2, -0.2);
	glTexCoord2f(1, 0);
	glVertex3f(0, -0.2, 0.2);
	glTexCoord2f(1, 1);
	glVertex3f(0, 0.2, 0.2);
	glTexCoord2f(0, 1);
	glVertex3f(0, 0.2, -0.2);
	glEnd();
	glPopMatrix();
	glPopAttrib();

	

	//-------------------------ALTIMETRO---------------------------------

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, altimetro);

	glTranslatef(camara[0], camara[1], camara[2]);
	glRotatef(anguloCamara, 0, 0, 1);
	glTranslatef(2, -0.4, -0.8);
	glRotatef(90, 1, 0, 0);
	glBegin(GL_POLYGON);
	glTexCoord2f(0, 0);
	glVertex3f(0, -0.2, -0.2);
	glTexCoord2f(1, 0);
	glVertex3f(0, -0.2, 0.2);
	glTexCoord2f(1, 1);
	glVertex3f(0, 0.2, 0.2);
	glTexCoord2f(0, 1);
	glVertex3f(0, 0.2, -0.2);
	glEnd();
	glPopMatrix();
	glPopAttrib();

	//-----------------------MANECILLA 2-----------------------------


	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, manecilla2);

	glTranslatef(camara[0], camara[1], camara[2]);
	glRotatef(anguloCamara, 0, 0, 1);
	glTranslatef(1.9, -0.39, -0.77);
	glRotatef(10, 1, 0, 0);
	glRotatef(camara[2], 1, 0, 0);
	glScalef(0, 0.8, 0.8);


	glBegin(GL_POLYGON);
	glTexCoord2f(0, 0);
	glVertex3f(0, -0.2, -0.2);
	glTexCoord2f(1, 0);
	glVertex3f(0, -0.2, 0.2);
	glTexCoord2f(1, 1);
	glVertex3f(0, 0.2, 0.2);
	glTexCoord2f(0, 1);
	glVertex3f(0, 0.2, -0.2);
	glEnd();
	glPopMatrix();
	glPopAttrib();

	
	FPS();

	//---------------------INFORMACION DEL CASCO--------------
	glPushAttrib(GL_CURRENT_BIT);
	glPushMatrix();
	texto(30, 140, (char*)"Velocidad = ", BLANCO, GLUT_BITMAP_HELVETICA_18, false);
	texto(140, 140, (char*)to_string(round(modulo)).c_str(), BLANCO, GLUT_BITMAP_HELVETICA_18, false);
	texto(220, 140, (char*)"km/h ", BLANCO, GLUT_BITMAP_HELVETICA_18, false);

	texto(30, 120, (char*)"Altitud = ", BLANCO, GLUT_BITMAP_HELVETICA_18, false);
	texto(110, 120, (char*)to_string(round(camara[2])).c_str(), BLANCO, GLUT_BITMAP_HELVETICA_18, false);
	texto(210, 120, (char*)"metros ", BLANCO, GLUT_BITMAP_HELVETICA_18, false);

	texto(30, 70, (char*)"Coordenada X = ", BLANCO, GLUT_BITMAP_HELVETICA_18, false);
	texto(170, 70, (char*)to_string(camara[0]).c_str(), BLANCO, GLUT_BITMAP_HELVETICA_18, false);

	texto(30, 50, (char*)"Coordenada Y = ", BLANCO, GLUT_BITMAP_HELVETICA_18, false);
	texto(170, 50, (char*)to_string(camara[1]).c_str(), BLANCO, GLUT_BITMAP_HELVETICA_18, false);

	texto(30, 570, (char*)"FPS = ", ROJO, GLUT_BITMAP_HELVETICA_18, false);
	texto(100, 570, (char*)to_string(fps).c_str(), ROJO, GLUT_BITMAP_HELVETICA_18, false);

	
	glPopMatrix();
	glPopAttrib();


	glutSwapBuffers();


	
	


}



void reshape(GLint w, GLint h)
{
	// w,h son las nuevas dimensiones de la ventana

	glViewport(0, 0, w, h);
	float ar = float(w) / h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();


	gluPerspective(60, float(w) / h, 1, 100000);


}



void subir() {
	camara[2] += 1;
}

void bajar() {
	if (camara[2] > 0) {
		camara[2] -= 1;
	}
}

void girarIzquierda() {
	anguloCamara += 1;
	giroY += 1;

}

void girarDerecha() {
	anguloCamara -= 1;
	giroY -= 1;
	
}

void cambioModo() {
	if (modo == DIA) {
		glClearColor(0.0f, 0.0f, 0.1f, 1.0f);
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT0);
		glEnable(GL_LIGHT1);
		glEnable(GL_LIGHT2);
		focoEncendido = true;
		glFogfv(GL_FOG_COLOR, nieblaNoche);
		modo = NOCHE;
	}
	else {
		glClearColor(0.0f, 1.0f, 1.0f, 1.0f);
		glDisable(GL_LIGHTING);
		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHT1);
		glDisable(GL_LIGHT2);
		glFogfv(GL_FOG_COLOR, nieblaDia);
		modo = DIA;
	}
}

void usarFoco() {
	if (focoEncendido) {
		glDisable(GL_LIGHT2);
		focoEncendido = !focoEncendido;
	}
	else {
		glEnable(GL_LIGHT2);
		focoEncendido = !focoEncendido;
	}
}

//Piloto automatico con las medias de los vertices m�s un offset
void pilotoAutomatico() {
	float alturaS = -alturaSuelo();
	//cout << alturaS << "\n";
	if (camara[2]  < alturaS +100) {
		camara[2] += 1;
	}
	else if (camara[2] > alturaS +100) {
		camara[2] -= 1;
	}


}

void onSpecialKey(int specialKey, int x, int y) {
	//Callback de atencion al teclado alfanumerico
	switch (specialKey) {
	case GLUT_KEY_UP:
		if (!pilotoAutoOn && camara[2]<280) {
			subir();
		}
		break;
	case GLUT_KEY_DOWN:
		if (!pilotoAutoOn) {
			bajar();
		}
		break;
	case GLUT_KEY_LEFT:
		girarIzquierda();
		break;
	case GLUT_KEY_RIGHT:
		girarDerecha();
		break;
	}
	glutPostRedisplay();
}

void onKey(unsigned char tecla, int x, int y) {
	//Callback de atencion al teclado alfanumerico
	switch (tecla) {
	case 'a':
		if(modulo < 280)
		modulo += 1;
		break;
	case 'z':
		if (modulo > 0) {
			modulo -= 1;
		}
		break;
	case 'l':
		cambioModo();
		break;
	case 'L':
		cambioModo();
		break;
	case 'f':
		if (modo == NOCHE)usarFoco();
		break;
	case 'F':
		if (modo == NOCHE)usarFoco();
		break;
	case 'q':
		if (!pilotoAutoOn) { 
			pilotoAutoOn = true;
		} else { pilotoAutoOn = false; }


	}
	glutPostRedisplay();
}

void onClick(int boton, int estado, int x, int y) {

	//Callback de atencion al evento de pulsado de un bot�n del rat�n
	static const float pixel2grados = 1.0;

	if (boton == GLUT_LEFT_BUTTON && estado == GLUT_DOWN) {
		
		xanterior = x;
		yanterior = y;
	}

	
}

void onDrag(int x, int y) {

	static const float pixel2grados = 1.0;
	static const float sensibilidad = 0.1;

	giroX += (y - yanterior) * pixel2grados * sensibilidad;
	giroY += (x - xanterior) * pixel2grados * sensibilidad;
	
	if (giroY > anguloCamara + 90 ) {
		giroY = anguloCamara + 90;
	}else if (giroY < anguloCamara - 90) {
		giroY = anguloCamara - 90;
	}

	if (giroX >  45) {
		giroX =  45;
	}
	else if (giroX <  - 89) {
		giroX =  - 89;
	}


	yanterior = y;
	xanterior = x;

	glutPostRedisplay();
}


void onIdle() {
	//callback de atencion a la cuenta atras de un timer
	int tiempo_transcurrido;
	static int antes = 0;
	int ahora = glutGet(GLUT_ELAPSED_TIME);
	tiempo_transcurrido = ahora - antes;

	camara[0] += cos(rad(anguloCamara)) * modulo * (tiempo_transcurrido / 1000.0);
	camara[1] += sin(rad(anguloCamara)) * modulo * (tiempo_transcurrido / 1000.0);
	antes = ahora;

	glutPostRedisplay();
}

void onTimer(int tiempo) {
	//callback de atencion a la cuenta atras de un timer

	//Encolarse a si misma
	glutTimerFunc(tiempo, onTimer, tiempo);

	onIdle();
	if (pilotoAutoOn) {
		pilotoAutomatico();
	}
}

int main(int argc, char** argv)
{
	// Inicializaciones
	FreeImage_Initialise();
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1000, 600);
	glutInitWindowPosition(0, 0);


	// Crear la ventana
	glutCreateWindow("Terreno");


	init(); //Estructuras de dato se construyen despu�s del CreateWindow


	// Seccion de registrode callbacks
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);

	glutSpecialFunc(onSpecialKey);
	glutKeyboardFunc(onKey);
	glutMouseFunc(onClick);
	glutMotionFunc(onDrag);
	glutTimerFunc(1000 / 60, onTimer, 1000 / 60);

	// Pone en marcha el bucle de atencion de evntos
	glutMainLoop();
	FreeImage_DeInitialise();
}